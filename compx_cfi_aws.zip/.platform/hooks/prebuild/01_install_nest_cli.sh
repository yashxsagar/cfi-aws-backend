#!/bin/bash
npm install -g @nestjs/cli
