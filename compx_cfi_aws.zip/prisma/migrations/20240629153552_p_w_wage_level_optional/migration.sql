-- AlterTable
ALTER TABLE "LCADisclosure" ALTER COLUMN "pwWageLevel" DROP NOT NULL;
