/*
  Warnings:

  - You are about to drop the column `workspaceName` on the `User` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "User" DROP COLUMN "workspaceName",
ADD COLUMN     "databaseId" TEXT;
