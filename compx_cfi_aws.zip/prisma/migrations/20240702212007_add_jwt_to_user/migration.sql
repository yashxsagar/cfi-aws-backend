-- AlterTable
ALTER TABLE "User" ADD COLUMN     "jwtToken" TEXT;
