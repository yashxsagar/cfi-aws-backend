export class Generatecfi {}
